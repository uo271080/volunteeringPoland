

<html>
<head>
<meta charset="utf-8">
<title>Main Menu</title>
<style>
	th {
		border: 1px solid black;
		background-color:#0071BD;
		color:white;
	}
	td{
		background-color:#80B9E0;
		text-align:center;
	}
	h1{
		text-align:center;
	}
	tr{
		text-align:center;
		width:250;
	}
</style>
</head>
<body bgcolor="#C6E8FF">
<form method='POST' action=''>

<h1>CHANGE USERNAME</h1>
<center>
<table border=0>
<tr>
<td style='text-align:center'>New username</td><td colspan=2><input type=text name='newUsername' size=15></td>
</tr>
<tr>
<td>Password</td><td colspan=2><input type=password name='passwordIntroduced' size=15></td>
<tr>
<tr>
<td colspan = 3 style ='text-align:center;background-color:#C6E8FF' ><input type=submit style = 'width:200'  value='Confirm' ></td>
<tr>
</center>


<?php
	session_start();
	$username = $_SESSION['username'];
	
	$server = mysqli_connect("localhost", "root", "")
                or exit("Connection with MySQL server failed");
	$database = mysqli_select_db($server, "ProjectDatabase") 
                or exit ("Connection with ProjectDatabase database failed");
	mysqli_set_charset($server, "utf8");

	$query = "select password from users where username='$username'";

	$result = mysqli_query($server, $query)
        or exit("Query $query failed");
	$record = mysqli_fetch_array($result);
	
	$password= $record[0];
	
	
	
	if(isset($_POST['passwordIntroduced']) && isset($_POST['newUsername'])){
		$password=$_POST['passwordIntroduced'];
		$newUsername=$_POST['newUsername'];
		$queryCount = "SELECT username from Users where username='$newUsername'";
		$result = mysqli_query($server, $query)
			or exit("Query $query failed");
		$record = mysqli_fetch_array($result);
		if($password==$passwordIntroduced && $newUsername!=$username){
			$updateQuery = "UPDATE users set username='$newUsername' where username='$username'";
			$result = mysqli_query($server, $query)
			or exit("Query $query failed");
			$record = mysqli_fetch_array($result);
			 echo "<script>
                alert('Username changed correctly');
                window.location= 'mainMenu.php'
				</script>";
		}
		else if(sizeOf($record)>0){
				echo "<script>
                alert('Username already exists.');
                window.location= 'changeUsername.php'
				</script>";	
		}
		else if($newUsername!=$username){
			echo "<script>
                alert('Username is the same as actual one.');
                window.location= 'changeUsername.php'
				</script>";	
		}
		else{
			echo "<script>
                alert('Incorrect password.');
                window.location= 'changeUsername.php'
				</script>";
		}
	}

?>
<a href='mainMenu.php'>Go back to Main Menu</a>

</body>
</html>
